import { type Alert } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Eye, AlertTriangle } from "lucide-react";

interface AlertsSidebarProps {
  alerts?: Alert[];
  isLoading: boolean;
}

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case "high":
      return "destructive";
    case "medium":
      return "default";
    case "low":
      return "secondary";
    default:
      return "secondary";
  }
};

const getSeverityBorderColor = (severity: string) => {
  switch (severity) {
    case "high":
      return "border-red-400";
    case "medium":
      return "border-orange-400";
    case "low":
      return "border-yellow-400";
    default:
      return "border-gray-400";
  }
};

const getAlertBgColor = (severity: string) => {
  switch (severity) {
    case "high":
      return "bg-red-50";
    case "medium":
      return "bg-orange-50";
    case "low":
      return "bg-yellow-50";
    default:
      return "bg-gray-50";
  }
};

const getAlertTextColor = (severity: string) => {
  switch (severity) {
    case "high":
      return "text-red-800";
    case "medium":
      return "text-orange-800";
    case "low":
      return "text-yellow-800";
    default:
      return "text-gray-800";
  }
};

export default function AlertsSidebar({ alerts, isLoading }: AlertsSidebarProps) {
  if (isLoading) {
    return (
      <Card className="shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <Skeleton className="h-6 w-32" />
            <Skeleton className="w-3 h-3 rounded-full" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-16 w-full" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-900">
            Latest Critical Alerts
          </CardTitle>
          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
        </div>
      </CardHeader>
      <CardContent>
        {!alerts || alerts.length === 0 ? (
          <div className="text-center py-8">
            <AlertTriangle className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No alerts</h3>
            <p className="mt-1 text-sm text-gray-500">
              No critical alerts at this time.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {alerts.map((alert) => (
              <div key={alert.id}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-medium text-gray-700 capitalize">
                    {alert.alertType.replace(/_/g, ' ')}
                  </h4>
                  <Badge variant={getSeverityColor(alert.severity)} className="text-xs">
                    {alert.severity}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className={`p-3 ${getAlertBgColor(alert.severity)} rounded-lg border-l-4 ${getSeverityBorderColor(alert.severity)}`}>
                    <p className={`text-sm ${getAlertTextColor(alert.severity)} font-medium`}>
                      {alert.message}
                    </p>
                    {alert.details && (
                      <p className={`text-xs ${getAlertTextColor(alert.severity)} mt-1 opacity-80`}>
                        {alert.details}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <Button className="w-full">
            <Eye className="h-4 w-4 mr-2" />
            View All Alerts
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
