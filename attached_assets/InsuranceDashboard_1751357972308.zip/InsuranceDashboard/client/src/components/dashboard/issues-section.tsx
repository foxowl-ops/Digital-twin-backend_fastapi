import { type Issue } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle, List, Copy, ArrowRightLeft } from "lucide-react";

interface IssuesSectionProps {
  issues?: Issue[];
  isLoading: boolean;
}

const getIssueIcon = (issueType: string) => {
  switch (issueType) {
    case "multiple_float":
      return List;
    case "double_payment":
      return Copy;
    case "different_refund_mode":
      return ArrowRightLeft;
    default:
      return List;
  }
};

const getIssueTitle = (issueType: string) => {
  switch (issueType) {
    case "multiple_float":
      return "Multiple Float Policies";
    case "double_payment":
      return "Double Payment";
    case "different_refund_mode":
      return "Different Refund Mode";
    default:
      return issueType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  }
};

export default function IssuesSection({ issues, isLoading }: IssuesSectionProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="shadow-sm">
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-16 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const issueTypes = ["multiple_float", "double_payment", "different_refund_mode"];
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {issueTypes.map((issueType) => {
        const Icon = getIssueIcon(issueType);
        const title = getIssueTitle(issueType);
        const issueData = issues?.filter(issue => issue.issueType === issueType) || [];

        return (
          <Card key={issueType} className="shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold text-gray-900">
                  {title}
                </CardTitle>
                <Icon className="h-5 w-5 text-gray-400" />
              </div>
            </CardHeader>
            <CardContent>
              {issueData.length === 0 ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="text-green-600 h-8 w-8" />
                  </div>
                  <p className="text-sm text-gray-500">No issues found</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {issueData.map((issue) => (
                    <div key={issue.id} className="p-3 bg-red-50 rounded-lg border border-red-200">
                      {issue.traceNo && (
                        <p className="text-sm font-medium text-red-800">
                          Trace no: <span className="font-mono">{issue.traceNo}</span>
                        </p>
                      )}
                      {issue.referenceId && (
                        <p className="text-xs text-red-600 mt-1">
                          Reference id: <span className="font-mono">{issue.referenceId}</span>
                        </p>
                      )}
                      {issue.receiptNo && (
                        <p className="text-sm font-medium text-yellow-800">
                          Receipt no: <span className="font-mono">{issue.receiptNo}</span>
                        </p>
                      )}
                      {issue.details && (
                        <p className="text-xs text-gray-600 mt-1">{issue.details}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
