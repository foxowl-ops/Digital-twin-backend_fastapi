import { CheckCircle, Receipt, FileText, Undo, ClipboardCheck } from "lucide-react";

interface MetricCardProps {
  title: string;
  count: string;
  amount: string;
  icon: string;
  color: "green" | "blue" | "purple" | "orange" | "teal";
}

const iconMap = {
  "check-circle": CheckCircle,
  "receipt": Receipt,
  "file-contract": FileText,
  "undo": Undo,
  "clipboard-check": ClipboardCheck,
};

const colorClasses = {
  green: "metric-card-green",
  blue: "metric-card-blue",
  purple: "metric-card-purple",
  orange: "metric-card-orange",
  teal: "metric-card-teal",
};

export default function MetricCard({ title, count, amount, icon, color }: MetricCardProps) {
  const IconComponent = iconMap[icon as keyof typeof iconMap];

  return (
    <div className={`${colorClasses[color]} rounded-xl p-6 text-white`}>
      <div className="flex items-center justify-between mb-4">
        <IconComponent className="h-6 w-6 opacity-80" />
        <span className="text-xs font-medium bg-white bg-opacity-20 px-2 py-1 rounded-full">
          Active
        </span>
      </div>
      <h3 className="text-sm font-medium opacity-90 mb-1">{title}</h3>
      <div className="space-y-1">
        <p className="text-2xl font-bold">{count}</p>
        <p className="text-sm opacity-80">Total amount: {amount}</p>
      </div>
    </div>
  );
}
