import { type CsvFile } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

interface UploadStatusTableProps {
  csvFiles: CsvFile[];
  isLoading: boolean;
}

export default function UploadStatusTable({ csvFiles, isLoading }: UploadStatusTableProps) {
  if (isLoading) {
    return (
      <div className="bg-gray-50 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Upload Status</h3>
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex space-x-4">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-16" />
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-24" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 rounded-xl p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Upload Status</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left border-b border-gray-200">
              <th className="pb-2 font-medium text-gray-700">File Type</th>
              <th className="pb-2 font-medium text-gray-700">Status</th>
              <th className="pb-2 font-medium text-gray-700">Size</th>
              <th className="pb-2 font-medium text-gray-700">Records</th>
              <th className="pb-2 font-medium text-gray-700">Upload Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {csvFiles.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-8 text-center text-gray-500">
                  No files uploaded yet
                </td>
              </tr>
            ) : (
              csvFiles.map((file) => (
                <tr key={file.id}>
                  <td className="py-2 text-gray-900 capitalize">
                    {file.fileType.replace(/-/g, ' ')}
                  </td>
                  <td className="py-2">
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      <span className="w-1.5 h-1.5 bg-green-400 rounded-full mr-1"></span>
                      {file.status}
                    </Badge>
                  </td>
                  <td className="py-2 text-gray-600">
                    {(file.fileSize / 1024).toFixed(2)} KB
                  </td>
                  <td className="py-2 text-gray-600">
                    {file.recordCount?.toLocaleString() || 'Processing...'}
                  </td>
                  <td className="py-2 text-gray-600">
                    {new Date(file.uploadedAt).toLocaleString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
