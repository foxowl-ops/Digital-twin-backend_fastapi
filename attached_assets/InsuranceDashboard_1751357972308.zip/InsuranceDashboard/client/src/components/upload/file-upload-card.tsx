import { useState } from "react";
import { type CsvFile } from "@shared/schema";
import { CreditCard, Receipt, FileText, Undo, ClipboardCheck, FileSpreadsheet, Settings } from "lucide-react";

interface FileUploadCardProps {
  fileType: string;
  label: string;
  icon: string;
  onFileUpload: (file: File, fileType: string) => void;
  isUploading: boolean;
  fileStatus?: CsvFile;
}

const iconMap = {
  "credit-card": CreditCard,
  "receipt": Receipt,
  "file-contract": FileText,
  "undo": Undo,
  "clipboard-check": ClipboardCheck,
  "clipboard-list": FileSpreadsheet,
  "cogs": Settings,
};

export default function FileUploadCard({ 
  fileType, 
  label, 
  icon, 
  onFileUpload, 
  isUploading, 
  fileStatus 
}: FileUploadCardProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const IconComponent = iconMap[icon as keyof typeof iconMap];
  const isUploaded = !!fileStatus;

  const handleFileSelect = (file: File) => {
    onFileUpload(file, fileType);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    const csvFile = files.find(file => file.name.endsWith('.csv'));
    
    if (csvFile) {
      handleFileSelect(csvFile);
    }
  };

  return (
    <div
      className={`border-2 border-dashed rounded-xl p-6 transition-colors cursor-pointer ${
        isDragOver 
          ? "border-blue-400 bg-blue-50" 
          : isUploaded 
            ? "border-green-400 bg-green-50" 
            : "border-gray-300 hover:border-blue-400"
      } ${isUploading ? "opacity-50 cursor-not-allowed" : ""}`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={() => {
        if (!isUploading) {
          const input = document.createElement('input');
          input.type = 'file';
          input.accept = '.csv';
          input.onchange = (e) => {
            const file = (e.target as HTMLInputElement).files?.[0];
            if (file) handleFileSelect(file);
          };
          input.click();
        }
      }}
    >
      <div className="text-center">
        <IconComponent className={`h-8 w-8 mx-auto mb-3 ${
          isUploaded ? "text-green-600" : "text-gray-400"
        }`} />
        <h4 className="text-sm font-medium text-gray-900 mb-1">{label}</h4>
        <p className="text-xs text-gray-500 mb-3">
          {isUploading ? "Uploading..." : isUploaded ? "File uploaded" : `Upload ${label.toLowerCase()} data`}
        </p>
        <div className="flex items-center justify-center space-x-2">
          <span className={`w-2 h-2 rounded-full ${
            isUploaded ? "bg-green-500" : "bg-gray-300"
          }`} />
          <span className={`text-xs ${
            isUploaded ? "text-green-600" : "text-gray-500"
          }`}>
            {isUploaded ? "Uploaded" : "Not uploaded"}
          </span>
        </div>
        
        {isUploaded && fileStatus && (
          <div className="mt-2 text-xs text-gray-600">
            <p>{fileStatus.recordCount?.toLocaleString()} records</p>
            <p>{(fileStatus.fileSize / 1024).toFixed(1)} KB</p>
          </div>
        )}
      </div>
    </div>
  );
}
