import { Link, useLocation } from "wouter";
import { ChartLine, Upload, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [location] = useLocation();

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <ChartLine className="text-blue-600 h-6 w-6 mr-3" />
              <h1 className="text-xl font-semibold text-gray-900">Payment System Digital Twin</h1>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button
                variant={location === "/" ? "default" : "outline"}
                size="sm"
                className="transition-colors"
              >
                <ChartLine className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <Link href="/upload">
              <Button
                variant={location === "/upload" ? "default" : "outline"}
                size="sm"
                className="transition-colors"
              >
                <Upload className="h-4 w-4 mr-2" />
                CSV Upload
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                <User className="text-white h-4 w-4" />
              </div>
              <span className="text-sm font-medium text-gray-700">Admin</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
