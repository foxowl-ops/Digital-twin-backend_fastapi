import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { type CsvFile } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import FileUploadCard from "@/components/upload/file-upload-card";
import UploadStatusTable from "@/components/upload/upload-status-table";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Database, Trash2, CheckCircle, Save } from "lucide-react";

const FILE_TYPES = [
  { key: "payment-transactions", label: "Payment Transactions", icon: "credit-card" },
  { key: "receipt-data", label: "Receipt Data", icon: "receipt" },
  { key: "policy-data", label: "Policy Data", icon: "file-contract" },
  { key: "refund-data", label: "Refund Data", icon: "undo" },
  { key: "claim-data", label: "Claim Data", icon: "clipboard-check" },
  { key: "audit-log", label: "Audit Log", icon: "clipboard-list" },
  { key: "configuration", label: "Configuration", icon: "cogs" },
];

export default function CsvUpload() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [uploadProgress, setUploadProgress] = useState(0);

  const { data: csvFiles = [], isLoading } = useQuery<CsvFile[]>({
    queryKey: ["/api/csv-files"],
  });

  const uploadMutation = useMutation({
    mutationFn: async ({ file, fileType }: { file: File; fileType: string }) => {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("fileType", fileType);

      const response = await apiRequest("POST", "/api/upload-csv", formData);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/csv-files"] });
      toast({
        title: "Upload successful",
        description: `CSV file uploaded with ${data.recordCount} records`,
      });
      updateProgress();
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const clearAllMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/csv-files/clear");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/csv-files"] });
      toast({
        title: "Files cleared",
        description: "All CSV files have been removed",
      });
      setUploadProgress(0);
    },
    onError: (error) => {
      toast({
        title: "Clear failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateProgress = () => {
    const uploadedCount = csvFiles.length;
    const progress = (uploadedCount / FILE_TYPES.length) * 100;
    setUploadProgress(progress);
  };

  const handleFileUpload = async (file: File, fileType: string) => {
    if (!file.name.endsWith('.csv')) {
      toast({
        title: "Invalid file type",
        description: "Please select a CSV file",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate({ file, fileType });
  };

  const getFileStatus = (fileType: string) => {
    return csvFiles.find(file => file.fileType === fileType);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Database className="text-blue-600 h-8 w-8" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">CSV Database Upload</h2>
          <p className="text-gray-600">Upload your 7 CSV database files to power the dashboard analytics</p>
        </div>

        {/* Upload Progress Overview */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Upload Progress</h3>
            <span className="text-sm text-gray-500">{csvFiles.length}/7 files uploaded</span>
          </div>
          <Progress value={uploadProgress} className="w-full" />
        </div>

        {/* File Upload Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {FILE_TYPES.map((fileType) => (
            <FileUploadCard
              key={fileType.key}
              fileType={fileType.key}
              label={fileType.label}
              icon={fileType.icon}
              onFileUpload={handleFileUpload}
              isUploading={uploadMutation.isPending}
              fileStatus={getFileStatus(fileType.key)}
            />
          ))}
        </div>

        <UploadStatusTable csvFiles={csvFiles} isLoading={isLoading} />

        {/* Action Buttons */}
        <div className="flex justify-between pt-6 mt-6 border-t border-gray-200">
          <Button
            variant="outline"
            onClick={() => clearAllMutation.mutate()}
            disabled={clearAllMutation.isPending || csvFiles.length === 0}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Clear All
          </Button>
          <div className="space-x-3">
            <Button variant="outline" disabled={csvFiles.length === 0}>
              <CheckCircle className="h-4 w-4 mr-2" />
              Validate Data
            </Button>
            <Button disabled={csvFiles.length === 0}>
              <Save className="h-4 w-4 mr-2" />
              Save & Process
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
