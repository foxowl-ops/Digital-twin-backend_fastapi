import { useQuery } from "@tanstack/react-query";
import { type PaymentMetrics, type CircleAlert, type Issue } from "@shared/schema";
import FilterSection from "@/components/dashboard/filter-section";
import MetricCard from "@/components/dashboard/metric-card";
import AlertsSidebar from "@/components/dashboard/alerts-sidebar";
import IssuesSection from "@/components/dashboard/issues-section";
import { Skeleton } from "@/components/ui/skeleton";
import { CircleAlert as AlertIcon, AlertTriangle } from "lucide-react";

function formatNumber(num: number): string {
  if (num >= 1000000000) {
    return (num / 1000000000).toFixed(2) + "G";
  } else if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M";
  } else if (num >= 1000) {
    return (num / 1000).toFixed(0) + "K";
  }
  return num.toString();
}

export default function Dashboard() {
  const { data: metrics, isLoading: metricsLoading } = useQuery<PaymentMetrics>({
    queryKey: ["/api/dashboard/metrics"],
  });

  const { data: alerts, isLoading: alertsLoading } = useQuery<CircleAlert[]>({
    queryKey: ["/api/dashboard/alerts"],
  });

  const { data: issues, isLoading: issuesLoading } = useQuery<Issue[]>({
    queryKey: ["/api/dashboard/issues"],
  });

  if (metricsLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  if (!metrics) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center py-12">
          <AlertTriangle className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No metrics available</h3>
          <p className="mt-1 text-sm text-gray-500">
            Please upload CSV files to see dashboard metrics.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <FilterSection />
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mt-8">
        <div className="lg:col-span-3">
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
            <MetricCard
              title="Payment Successful"
              count={formatNumber(metrics.paymentSuccessfulCount)}
              amount={formatNumber(metrics.paymentSuccessfulAmount)}
              icon="check-circle"
              color="green"
            />
            <MetricCard
              title="Receipt Generated"
              count={formatNumber(metrics.receiptGeneratedCount)}
              amount={formatNumber(metrics.receiptGeneratedAmount)}
              icon="receipt"
              color="blue"
            />
            <MetricCard
              title="Policy Created"
              count={formatNumber(metrics.policyCreatedCount)}
              amount={formatNumber(metrics.policyCreatedAmount)}
              icon="file-contract"
              color="purple"
            />
            <MetricCard
              title="Refund Processed"
              count={formatNumber(metrics.refundProcessedCount)}
              amount={formatNumber(metrics.refundProcessedAmount)}
              icon="undo"
              color="orange"
            />
            <MetricCard
              title="Claim Processed"
              count={formatNumber(metrics.claimProcessedCount)}
              amount={formatNumber(metrics.claimProcessedAmount)}
              icon="clipboard-check"
              color="teal"
            />
          </div>

          <IssuesSection issues={issues} isLoading={issuesLoading} />
        </div>

        <div className="lg:col-span-1">
          <AlertsSidebar alerts={alerts} isLoading={alertsLoading} />
        </div>
      </div>
    </div>
  );
}
