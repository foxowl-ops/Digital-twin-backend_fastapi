# Payment System Digital Twin

## Overview

This is a Payment System Digital Twin application built with a full-stack TypeScript architecture. It's designed to monitor, analyze, and visualize payment system data through CSV file uploads and real-time dashboard metrics. The application provides insights into payment transactions, receipts, policies, refunds, and claims processing.

## System Architecture

The application follows a modern full-stack architecture with clear separation between frontend, backend, and shared components:

- **Frontend**: React-based SPA with TypeScript
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state
- **File Processing**: Multer for CSV uploads
- **Development**: Vite for bundling and hot reload

## Key Components

### Frontend Architecture

The frontend is built with React and uses a component-based architecture:

- **Routing**: Wouter for client-side routing
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack Query for server state synchronization
- **Styling**: Tailwind CSS with custom design tokens
- **Form Handling**: React Hook Form with Zod validation

Key pages:
- Dashboard: Real-time metrics and alerts visualization
- CSV Upload: File upload interface with drag-and-drop support
- Responsive design with mobile-first approach

### Backend Architecture

The backend uses Express.js with TypeScript:

- **API Structure**: RESTful endpoints under `/api` prefix
- **File Upload**: Multer middleware for CSV processing with 10MB limit
- **Error Handling**: Centralized error middleware
- **Logging**: Custom request/response logging
- **CORS**: Configured for development environment

### Database Schema

Using Drizzle ORM with PostgreSQL, the schema includes:

- **users**: Authentication and user management
- **csvFiles**: File upload metadata tracking
- **paymentMetrics**: Aggregated payment system metrics
- **alerts**: System alerts with severity levels
- **issues**: Problem tracking and resolution

The schema supports payment transaction flows, receipt generation, policy creation, refund processing, and claim management.

## Data Flow

1. **CSV Upload Flow**:
   - User uploads CSV files through drag-and-drop interface
   - Files are validated (CSV only, 10MB limit)
   - CSV content is parsed and stored
   - Metadata is tracked in database
   - Success/error feedback provided

2. **Dashboard Metrics Flow**:
   - Real-time queries to payment metrics
   - Data aggregation for different transaction types
   - Alert generation based on thresholds
   - Issue tracking and resolution status

3. **Real-time Updates**:
   - TanStack Query manages cache invalidation
   - Automatic refetching on focus/mount
   - Optimistic updates for better UX

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL driver
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect
- **@tanstack/react-query**: Server state management
- **multer**: File upload handling
- **zod**: Runtime type validation
- **react-hook-form**: Form state management

### UI Dependencies
- **@radix-ui/***: Headless UI primitives
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library
- **class-variance-authority**: Variant-based styling
- **date-fns**: Date manipulation

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Type safety
- **eslint**: Code linting
- **prettier**: Code formatting

## Deployment Strategy

The application is configured for modern deployment:

- **Build Process**: Vite builds frontend, esbuild bundles backend
- **Environment**: Supports both development and production modes
- **Database**: Uses environment variable for DATABASE_URL
- **Static Assets**: Frontend builds to `dist/public`
- **Process Management**: Uses Node.js ESM modules

### Development
- `npm run dev`: Starts development server with hot reload
- `npm run check`: TypeScript type checking
- `npm run db:push`: Database schema migration

### Production
- `npm run build`: Creates production builds
- `npm start`: Runs production server
- Environment variables required: DATABASE_URL

The architecture supports horizontal scaling and can be deployed to cloud platforms with PostgreSQL database services.

## Changelog

```
Changelog:
- July 01, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```