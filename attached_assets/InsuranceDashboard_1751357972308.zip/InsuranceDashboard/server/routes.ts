import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCsvFileSchema, insertPaymentMetricsSchema, insertAlertSchema, insertIssueSchema } from "@shared/schema";
import multer from "multer";
import { z } from "zod";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv')) {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'));
    }
  }
});

function parseCSV(csvContent: string): any[] {
  const lines = csvContent.split('\n').filter(line => line.trim());
  if (lines.length < 2) return [];
  
  const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
  const data = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
    if (values.length === headers.length) {
      const row: any = {};
      headers.forEach((header, index) => {
        row[header] = values[index];
      });
      data.push(row);
    }
  }
  
  return data;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get dashboard metrics
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const metrics = await storage.getPaymentMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch metrics" });
    }
  });

  // Get alerts
  app.get("/api/dashboard/alerts", async (req, res) => {
    try {
      const alerts = await storage.getUnresolvedAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // Get issues
  app.get("/api/dashboard/issues", async (req, res) => {
    try {
      const issues = await storage.getIssues();
      res.json(issues);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch issues" });
    }
  });

  // Get CSV files
  app.get("/api/csv-files", async (req, res) => {
    try {
      const csvFiles = await storage.getCsvFiles();
      res.json(csvFiles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch CSV files" });
    }
  });

  // Upload CSV file
  app.post("/api/upload-csv", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file provided" });
      }

      const { fileType } = req.body;
      if (!fileType) {
        return res.status(400).json({ error: "File type is required" });
      }

      const csvContent = req.file.buffer.toString('utf-8');
      const parsedData = parseCSV(csvContent);

      // Store CSV data
      await storage.storeCsvData(fileType, parsedData);

      // Create CSV file record
      const csvFileData = insertCsvFileSchema.parse({
        fileName: req.file.originalname,
        fileType,
        fileSize: req.file.size,
        recordCount: parsedData.length,
        status: "processed"
      });

      const csvFile = await storage.createCsvFile(csvFileData);

      res.json({ 
        success: true, 
        csvFile,
        recordCount: parsedData.length 
      });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ error: "Failed to upload CSV file" });
    }
  });

  // Delete CSV file
  app.delete("/api/csv-files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteCsvFile(id);
      
      if (success) {
        res.json({ success: true });
      } else {
        res.status(404).json({ error: "CSV file not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete CSV file" });
    }
  });

  // Clear all CSV files
  app.post("/api/csv-files/clear", async (req, res) => {
    try {
      const csvFiles = await storage.getCsvFiles();
      for (const file of csvFiles) {
        await storage.deleteCsvFile(file.id);
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear CSV files" });
    }
  });

  // Update payment metrics
  app.put("/api/dashboard/metrics", async (req, res) => {
    try {
      const metricsData = insertPaymentMetricsSchema.parse(req.body);
      const metrics = await storage.updatePaymentMetrics(metricsData);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to update metrics" });
    }
  });

  // Create alert
  app.post("/api/dashboard/alerts", async (req, res) => {
    try {
      const alertData = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(alertData);
      res.json(alert);
    } catch (error) {
      res.status(500).json({ error: "Failed to create alert" });
    }
  });

  // Create issue
  app.post("/api/dashboard/issues", async (req, res) => {
    try {
      const issueData = insertIssueSchema.parse(req.body);
      const issue = await storage.createIssue(issueData);
      res.json(issue);
    } catch (error) {
      res.status(500).json({ error: "Failed to create issue" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
