import { users, csvFiles, paymentMetrics, alerts, issues, type User, type InsertUser, type CsvFile, type InsertCsvFile, type PaymentMetrics, type InsertPaymentMetrics, type Alert, type InsertAlert, type Issue, type InsertIssue } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // CSV file methods
  getCsvFiles(): Promise<CsvFile[]>;
  getCsvFile(id: number): Promise<CsvFile | undefined>;
  createCsvFile(csvFile: InsertCsvFile): Promise<CsvFile>;
  updateCsvFile(id: number, updates: Partial<CsvFile>): Promise<CsvFile | undefined>;
  deleteCsvFile(id: number): Promise<boolean>;
  
  // Payment metrics methods
  getPaymentMetrics(): Promise<PaymentMetrics | undefined>;
  updatePaymentMetrics(metrics: InsertPaymentMetrics): Promise<PaymentMetrics>;
  
  // Alert methods
  getAlerts(): Promise<Alert[]>;
  getUnresolvedAlerts(): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: number, updates: Partial<Alert>): Promise<Alert | undefined>;
  
  // Issue methods
  getIssues(): Promise<Issue[]>;
  getIssuesByType(issueType: string): Promise<Issue[]>;
  createIssue(issue: InsertIssue): Promise<Issue>;
  updateIssue(id: number, updates: Partial<Issue>): Promise<Issue | undefined>;
  
  // CSV data storage methods
  storeCsvData(fileType: string, data: any[]): Promise<void>;
  getCsvData(fileType: string): Promise<any[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private csvFiles: Map<number, CsvFile>;
  private paymentMetrics: PaymentMetrics | undefined;
  private alerts: Map<number, Alert>;
  private issues: Map<number, Issue>;
  private csvData: Map<string, any[]>;
  private currentUserId: number;
  private currentCsvFileId: number;
  private currentAlertId: number;
  private currentIssueId: number;

  constructor() {
    this.users = new Map();
    this.csvFiles = new Map();
    this.alerts = new Map();
    this.issues = new Map();
    this.csvData = new Map();
    this.currentUserId = 1;
    this.currentCsvFileId = 1;
    this.currentAlertId = 1;
    this.currentIssueId = 1;
    
    // Initialize with default metrics
    this.paymentMetrics = {
      id: 1,
      paymentSuccessfulCount: 241000,
      paymentSuccessfulAmount: 1510000000,
      receiptGeneratedCount: 241200,
      receiptGeneratedAmount: 1510000000,
      policyCreatedCount: 253000,
      policyCreatedAmount: 1240000000,
      refundProcessedCount: 4060,
      refundProcessedAmount: 14700000,
      claimProcessedCount: 25710,
      claimProcessedAmount: 3120000000,
      lastUpdated: new Date(),
    };
    
    // Initialize sample alerts
    this.createAlert({
      alertType: "amount_mismatch",
      severity: "high",
      message: "Amount mismatch detected",
      details: "Amount mismatch table",
    });
    
    this.createAlert({
      alertType: "receipt_residue",
      severity: "medium",
      message: "Receipt residue found",
      details: "Receipt no: RCP123456789, Residue amount: €77",
    });
    
    this.createAlert({
      alertType: "untouched_receipt",
      severity: "low",
      message: "Untouched receipt found",
      details: "Receipt no: RCP987654321, Untouched amount: 4630",
    });
    
    // Initialize sample issues
    this.createIssue({
      issueType: "double_payment",
      traceNo: "TRC123456789",
      referenceId: "REF987654321",
      details: "Double payment detected",
    });
    
    this.createIssue({
      issueType: "different_refund_mode",
      receiptNo: "RCP123456789",
      details: "Refund mode: Transfer",
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCsvFiles(): Promise<CsvFile[]> {
    return Array.from(this.csvFiles.values());
  }

  async getCsvFile(id: number): Promise<CsvFile | undefined> {
    return this.csvFiles.get(id);
  }

  async createCsvFile(insertCsvFile: InsertCsvFile): Promise<CsvFile> {
    const id = this.currentCsvFileId++;
    const csvFile: CsvFile = {
      ...insertCsvFile,
      id,
      uploadedAt: new Date(),
    };
    this.csvFiles.set(id, csvFile);
    return csvFile;
  }

  async updateCsvFile(id: number, updates: Partial<CsvFile>): Promise<CsvFile | undefined> {
    const csvFile = this.csvFiles.get(id);
    if (!csvFile) return undefined;
    
    const updatedCsvFile = { ...csvFile, ...updates };
    this.csvFiles.set(id, updatedCsvFile);
    return updatedCsvFile;
  }

  async deleteCsvFile(id: number): Promise<boolean> {
    return this.csvFiles.delete(id);
  }

  async getPaymentMetrics(): Promise<PaymentMetrics | undefined> {
    return this.paymentMetrics;
  }

  async updatePaymentMetrics(metrics: InsertPaymentMetrics): Promise<PaymentMetrics> {
    this.paymentMetrics = {
      id: 1,
      ...metrics,
      lastUpdated: new Date(),
    };
    return this.paymentMetrics;
  }

  async getAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values());
  }

  async getUnresolvedAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values()).filter(alert => !alert.resolved);
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = this.currentAlertId++;
    const alert: Alert = {
      ...insertAlert,
      id,
      createdAt: new Date(),
      resolved: false,
    };
    this.alerts.set(id, alert);
    return alert;
  }

  async updateAlert(id: number, updates: Partial<Alert>): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;
    
    const updatedAlert = { ...alert, ...updates };
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }

  async getIssues(): Promise<Issue[]> {
    return Array.from(this.issues.values());
  }

  async getIssuesByType(issueType: string): Promise<Issue[]> {
    return Array.from(this.issues.values()).filter(issue => issue.issueType === issueType);
  }

  async createIssue(insertIssue: InsertIssue): Promise<Issue> {
    const id = this.currentIssueId++;
    const issue: Issue = {
      ...insertIssue,
      id,
      createdAt: new Date(),
      status: "open",
    };
    this.issues.set(id, issue);
    return issue;
  }

  async updateIssue(id: number, updates: Partial<Issue>): Promise<Issue | undefined> {
    const issue = this.issues.get(id);
    if (!issue) return undefined;
    
    const updatedIssue = { ...issue, ...updates };
    this.issues.set(id, updatedIssue);
    return updatedIssue;
  }

  async storeCsvData(fileType: string, data: any[]): Promise<void> {
    this.csvData.set(fileType, data);
  }

  async getCsvData(fileType: string): Promise<any[]> {
    return this.csvData.get(fileType) || [];
  }
}

export const storage = new MemStorage();
