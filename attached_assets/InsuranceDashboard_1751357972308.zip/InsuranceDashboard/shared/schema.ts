import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const csvFiles = pgTable("csv_files", {
  id: serial("id").primaryKey(),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size").notNull(),
  recordCount: integer("record_count"),
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull(),
  status: text("status").notNull().default("uploaded"),
});

export const paymentMetrics = pgTable("payment_metrics", {
  id: serial("id").primaryKey(),
  paymentSuccessfulCount: integer("payment_successful_count").notNull().default(0),
  paymentSuccessfulAmount: real("payment_successful_amount").notNull().default(0),
  receiptGeneratedCount: integer("receipt_generated_count").notNull().default(0),
  receiptGeneratedAmount: real("receipt_generated_amount").notNull().default(0),
  policyCreatedCount: integer("policy_created_count").notNull().default(0),
  policyCreatedAmount: real("policy_created_amount").notNull().default(0),
  refundProcessedCount: integer("refund_processed_count").notNull().default(0),
  refundProcessedAmount: real("refund_processed_amount").notNull().default(0),
  claimProcessedCount: integer("claim_processed_count").notNull().default(0),
  claimProcessedAmount: real("claim_processed_amount").notNull().default(0),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  alertType: text("alert_type").notNull(),
  severity: text("severity").notNull(),
  message: text("message").notNull(),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  resolved: boolean("resolved").notNull().default(false),
});

export const issues = pgTable("issues", {
  id: serial("id").primaryKey(),
  issueType: text("issue_type").notNull(),
  traceNo: text("trace_no"),
  referenceId: text("reference_id"),
  receiptNo: text("receipt_no"),
  details: text("details"),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCsvFileSchema = createInsertSchema(csvFiles).omit({
  id: true,
  uploadedAt: true,
});

export const insertPaymentMetricsSchema = createInsertSchema(paymentMetrics).omit({
  id: true,
  lastUpdated: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

export const insertIssueSchema = createInsertSchema(issues).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type CsvFile = typeof csvFiles.$inferSelect;
export type InsertCsvFile = z.infer<typeof insertCsvFileSchema>;
export type PaymentMetrics = typeof paymentMetrics.$inferSelect;
export type InsertPaymentMetrics = z.infer<typeof insertPaymentMetricsSchema>;
export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Issue = typeof issues.$inferSelect;
export type InsertIssue = z.infer<typeof insertIssueSchema>;
